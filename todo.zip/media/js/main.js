$(".form-signin").click(function () {
    $(".home").hide();
});

$(".form-signin").click(function () {
    $(".cards").show();
    $(".footer").show();
});

$(".carta").click(function () {
    $(".cards").hide();
});

$(".carta").click(function () {
    $(".problema").show();
    $(".footer").show();
});

$("#reporte").click(function () {

    $(".problema").hide();
    $(".form").show();
});